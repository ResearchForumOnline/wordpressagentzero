jQuery(document).ready(function ($) {
  const container = $('#agent-zero-chat');
  const messages = container.find('.agent-zero-messages');
  const input = container.find('.agent-zero-input');
  const sendBtn = container.find('.agent-zero-send');

  function appendMessage(role, text) {
    messages.append(`<div class="msg ${role}">${text}</div>`);
  }

  sendBtn.on('click', function () {
    const text = input.val();
    if (!text) return;
    appendMessage('user', text);
    input.val('');
    $.post(AgentZero.ajax_url, { action: 'wp_agent_zero_chat', message: text }, function (data) {
      let reply = data;
      try {
        const obj = JSON.parse(data);
        reply = obj.choices[0].message.content;
      } catch (e) {}
      appendMessage('assistant', reply);
    });
  });
});