# Agent Zero WordPress Plugin

Adds a powerful GPT-4 chatbot widget to your WordPress site. Includes advanced configuration options and UI.

## Usage

1. Upload the plugin via WordPress or extract it into `/wp-content/plugins/`
2. Activate the plugin.
3. Configure your OpenAI API key and agent file in **Settings > Agent Zero**.
4. Use `[agent_zero_chat]` shortcode to embed the widget.
