<?php
/*
Plugin Name: Agent Zero Chatbot
Description: GPT-4 powered chatbot widget with agent configuration.
Version: 1.1.0
Author: Zero Dev Team
*/

if (!defined('ABSPATH')) exit;

const WP_AGENT_ZERO_OPTION = 'wp_agent_zero_options';
const WP_AGENT_ZERO_FILE = 'agent-data.json';

function wp_agent_zero_default_options() {
    return [
        'openai_api_key' => '',
        'agent_file' => plugin_dir_path(__FILE__) . 'agent-data/default.json',
    ];
}

function wp_agent_zero_get_options() {
    return wp_parse_args(get_option(WP_AGENT_ZERO_OPTION, []), wp_agent_zero_default_options());
}

add_action('admin_menu', function() {
    add_options_page('Agent Zero', 'Agent Zero', 'manage_options', 'wp-agent-zero', function () {
        if (!current_user_can('manage_options')) return;
        if ($_POST['wp_agent_zero_save']) {
            check_admin_referer('wp_agent_zero_settings');
            update_option(WP_AGENT_ZERO_OPTION, [
                'openai_api_key' => sanitize_text_field($_POST['openai_api_key']),
                'agent_file' => sanitize_text_field($_POST['agent_file']),
            ]);
            echo '<div class="updated"><p>Settings saved.</p></div>';
        }
        $opts = wp_agent_zero_get_options(); ?>
        <div class="wrap">
            <h1>Agent Zero Settings</h1>
            <form method="post">
                <?php wp_nonce_field('wp_agent_zero_settings'); ?>
                <table class="form-table">
                    <tr><th><label>OpenAI API Key</label></th>
                        <td><input name="openai_api_key" value="<?php echo esc_attr($opts['openai_api_key']); ?>" class="regular-text" /></td></tr>
                    <tr><th><label>Agent File</label></th>
                        <td><input name="agent_file" value="<?php echo esc_attr($opts['agent_file']); ?>" class="regular-text" /></td></tr>
                </table>
                <?php submit_button('Save Settings', 'primary', 'wp_agent_zero_save'); ?>
            </form>
        </div>
    <?php });
});

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_script('wp-agent-zero-chat', plugins_url('chat.js', __FILE__), ['jquery'], '1.0', true);
    wp_localize_script('wp-agent-zero-chat', 'AgentZero', ['ajax_url' => admin_url('admin-ajax.php')]);
});

add_action('wp_ajax_wp_agent_zero_chat', 'wp_agent_zero_chat_endpoint');
add_action('wp_ajax_nopriv_wp_agent_zero_chat', 'wp_agent_zero_chat_endpoint');

function wp_agent_zero_chat_endpoint() {
    $opts = wp_agent_zero_get_options();
    $message = sanitize_text_field($_POST['message'] ?? '');
    $sys_msg = json_decode(file_get_contents($opts['agent_file']), true);
    $payload = [
        'model' => 'gpt-4o',
        'messages' => [
            ['role' => 'system', 'content' => $sys_msg['description']],
            ['role' => 'user', 'content' => $message],
        ],
    ];
    $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
        'body' => json_encode($payload),
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $opts['openai_api_key'],
        ],
    ]);
    wp_send_json(wp_remote_retrieve_body($response));
}

add_shortcode('agent_zero_chat', function() {
    ob_start(); ?>
    <div id="agent-zero-chat">
        <div class="agent-zero-messages"></div>
        <input type="text" class="agent-zero-input" placeholder="Say something...">
        <button class="agent-zero-send">Send</button>
    </div>
    <?php return ob_get_clean();
});
